package com.mycompany.ultraemojicombat;

public class Luta {
    private Lutador desafiado;
    private Lutador desafiante;
    private int rounds;
    private boolean aprovada;
    
    public void marcarLuta(Lutador l1, l2){
        if (l1.getCategoria() = l2.getCategoria()) && (l1 =! l2){
            this.aprovada = true;
            this.desafiado = l1;
            this.desafiante = l2;
        } else{
                
                }
    };
    
    public void lutar(){
        // if (desafiado && desafiante == categoria);
        //if (desafiado != desafiante)
        // if (aprovada)
    };
    
    // GETTERS AND SETTERS
    public Lutador getDesafiado(){
        return this.desafiado;
    };
    
    public void setDesafiado(Lutador desafiado){
        this.desafiado = desafiado;
    };
}